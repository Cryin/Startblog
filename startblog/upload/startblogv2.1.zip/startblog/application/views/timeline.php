
<!-- content srart -->
<div class="am-g am-g-fixed blog-fixed blog-content">
    <div class="am-u-sm-12">
        <h1 class="blog-text-center">-- Timeline --</h1>
        <div class="timeline-year">
            <h1>2016</h1>
            <hr>
                <ul>
                <h3>11月</h3>
                <hr>
                <li>
                    <span class="am-u-sm-4 am-u-md-2 timeline-span">2016/11/25</span>
                    <span class="am-u-sm-8 am-u-md-6"><a href="#">修复dreamkill同学提出的程序bug</a></span>
                    <span class="am-u-sm-4 am-u-md-2 am-hide-sm-only">修复bug</span>
                    <span class="am-u-sm-4 am-u-md-2 am-hide-sm-only">startblog v2.1</span>
                </li>
                <li>
                    <span class="am-u-sm-4 am-u-md-2 timeline-span">2016/11/24</span>
                    <span class="am-u-sm-8 am-u-md-6"><a href="#">修改文章编辑界面、增加友情链接编辑、排序功能</a></span>
                    <span class="am-u-sm-4 am-u-md-2 am-hide-sm-only">修复bug</span>
                    <span class="am-u-sm-4 am-u-md-2 am-hide-sm-only">startblog v2.1</span>
                </li>
				<li>
                    <span class="am-u-sm-4 am-u-md-2 timeline-span">2016/11/16</span>
                    <span class="am-u-sm-8 am-u-md-6"><a href="#">修复文章编辑后浏览数PV数量被重置为1的bug</a></span>
                    <span class="am-u-sm-4 am-u-md-2 am-hide-sm-only">修复bug</span>
                    <span class="am-u-sm-4 am-u-md-2 am-hide-sm-only">startblog v2.0</span>
                </li>
                <li>
                    <span class="am-u-sm-4 am-u-md-2 timeline-span">2016/11/14</span>
                    <span class="am-u-sm-8 am-u-md-6"><a href="#">全面升级UI，采用Amazeui开发后台及前端UI</a></span>
                    <span class="am-u-sm-4 am-u-md-2 am-hide-sm-only">更新</span>
                    <span class="am-u-sm-4 am-u-md-2 am-hide-sm-only">startblog v2.0</span>
                </li>
                <li>
                    <span class="am-u-sm-4 am-u-md-2 timeline-span">2016/11/10</span>
                    <span class="am-u-sm-8 am-u-md-6"><a href="#">修复install目录不存在bug，完善安装向导</a></span>
                    <span class="am-u-sm-4 am-u-md-2 am-hide-sm-only">修复bug</span>
                    <span class="am-u-sm-4 am-u-md-2 am-hide-sm-only">startblog v1.6</span>
                </li>
                </ul>
                <br>
                <ul>
                <br>
                <h3>10月</h3>
                <hr>
                <li>
                    <span class="am-u-sm-4 am-u-md-2 timeline-span">2016/10/24</span>
                    <span class="am-u-sm-8 am-u-md-6"><a href="#">更新Markdown编辑控件，使用simplemde编辑器。parsedown解析</a></span>
                    <span class="am-u-sm-4 am-u-md-2 am-hide-sm-only">更新</span>
                    <span class="am-u-sm-4 am-u-md-2 am-hide-sm-only">v1.5</span>
                </li>
                
                
                </ul>
                <br>               
                <ul>
                <br>
                <h3>8月</h3>
                <hr>
                <li>
                    <span class="am-u-sm-4 am-u-md-2 timeline-span">2016/8/1</span>
                    <span class="am-u-sm-8 am-u-md-6"><a href="#">增加rss订阅功能</a></span>
                    <span class="am-u-sm-4 am-u-md-2 am-hide-sm-only">更新</span>
                    <span class="am-u-sm-4 am-u-md-2 am-hide-sm-only">v1.3</span>
                </li>
                <li>
                    <span class="am-u-sm-4 am-u-md-2 timeline-span">2016/8/5</span>
                    <span class="am-u-sm-8 am-u-md-6"><a href="#">增加安装install功能</a></span>
                    <span class="am-u-sm-4 am-u-md-2 am-hide-sm-only">更新</span>
                    <span class="am-u-sm-4 am-u-md-2 am-hide-sm-only">startblog v1.4</span>
                </li>
                
                </ul>
                <br>               
                <ul>
                <br>
                <h3>7月</h3>
                <hr>
                <li>
                    <span class="am-u-sm-4 am-u-md-2 timeline-span">2016/7/27</span>
                    <span class="am-u-sm-8 am-u-md-6"><a href="#">完成站点SEO功能，增加url rewrite，完成文章页面seo功能，添加登录logo</a></span>
                    <span class="am-u-sm-4 am-u-md-2 am-hide-sm-only">更新</span>
                    <span class="am-u-sm-4 am-u-md-2 am-hide-sm-only">startblog v1.2</span>
                </li>
                <li>
                    <span class="am-u-sm-4 am-u-md-2 timeline-span">2016/7/22</span>
                    <span class="am-u-sm-8 am-u-md-6"><a href="#">修复站点xss漏洞</a></span>
                    <span class="am-u-sm-4 am-u-md-2 am-hide-sm-only">修复漏洞</span>
                    <span class="am-u-sm-4 am-u-md-2 am-hide-sm-only">startblog v1.1</span>
                </li>
                
                </ul>
        </div>
        <div class="timeline-year">
            <h1>2015</h1>
            <hr>
                <ul>
                <h3>3月</h3>
                <hr>
                <li>
                    <span class="am-u-sm-4 am-u-md-2 timeline-span">2015/3/27</span>
                    <span class="am-u-sm-8 am-u-md-6"><a href="#">实现markdown编辑器与解析</a></span>
                    <span class="am-u-sm-4 am-u-md-2 am-hide-sm-only">更新</span>
                    <span class="am-u-sm-4 am-u-md-2 am-hide-sm-only">startblog v1.0</span>
                </li>
                
                </ul>
                <br>
        </div>
        <div class="timeline-year">
            <h1>2014</h1>
            <hr>
                <ul>
                <h3>9月</h3>
                <hr>
                <li>
                    <span class="am-u-sm-4 am-u-md-2 timeline-span">2014/9/18</span>
                    <span class="am-u-sm-8 am-u-md-6"><a href="#">初识CodeIgniter，编写博客程序</a></span>
                    <span class="am-u-sm-4 am-u-md-2 am-hide-sm-only">更新</span>
                    <span class="am-u-sm-4 am-u-md-2 am-hide-sm-only">startblog诞生</span>
                </li>
                
                </ul>
                <br>
        </div>
        

        <hr>
    </div>


</div>  