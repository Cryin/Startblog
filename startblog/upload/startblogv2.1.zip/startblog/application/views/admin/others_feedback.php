<!-- 内容区域 -->
        <div class="tpl-content-wrapper">

            <div class="container-fluid am-cf">
                <div class="row">
                    <div class="am-u-sm-12 am-u-md-12 am-u-lg-9">
                        <div class="page-header-heading"><span class="am-icon-cog page-header-heading-icon"></span> 问题反馈 <small>Feedback</small></div>
                        <p class="page-header-description">程序使用及Bug问题反馈</p>
                    </div>
                </div>

            </div>
<div class="row">

                    <div class="am-u-sm-12 am-u-md-12 am-u-lg-12">
                            
                            <div class="row am-cf">
                <div class="am-u-sm-12 am-u-md-12 am-u-lg-12 widget-margin-bottom-lg ">
                        <div class="tpl-user-card am-text-center widget-body-lg">
                            <div class="tpl-user-card-title">
                                Startblog
                            </div>
                            <div class="achievement-subheading">
                               一款基于Codeigniter、Html5开发的简洁、易用、跨平台自适应的Markdown博客系统，<br/>
                               本着大道至简的原则，本Blog程序只维持最基本的Blog形态，不会轻易增加其它功能。有问题可以反馈到Issues！<br/>
                               Github地址: https://github.com/Cryin/Startblog
                            </div>
                            <img class="achievement-image" src="<?php echo base_url('/static/admin/img/logob.png')?>" alt="">
                            <div class="achievement-description">
                                开发者: </b>Cryin<br/>
                                反馈QQ: </b>416049355<br/>
                                感谢反馈者: </b>dreamkill、xiao8Git、JunJun-Love-Amber<br/>
                                </div>
                    <p class="copyright">
                        © 2014-2016 Cryin' | Images : www.startblog.cc<a href="http://www.startblog.cc/"></a>
                    </p>
                            
                        </div>
                    </div>



                        </div>
                    </div>
                </div>
</div>
        </div>