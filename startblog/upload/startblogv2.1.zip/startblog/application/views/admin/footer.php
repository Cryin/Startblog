    <script src="<?php echo base_url('/static/admin/js/amazeui.min.js')?>"></script>
    <script src="<?php echo base_url('/static/admin/js/amazeui.datatables.min.js')?>"></script>
    <script src="<?php echo base_url('/static/admin/js/dataTables.responsive.min.js')?>"></script>
    <script src="<?php echo base_url('/static/admin/js/app.js')?>"></script>

</body>

</html>
