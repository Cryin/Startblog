<footer class="blog-footer">
    <div class="am-g am-g-fixed blog-fixed am-u-sm-centered blog-footer-padding">
        <div class="am-u-sm-12 am-u-md-4- am-u-lg-4">
            <h3>关于 StartBlog</h3>
            <p class="am-text-sm">一款基于Codeigniter、Amazeui(Html5)开发的简洁、易用、跨平台自适应的Markdown博客系统.<br> 使用Amaze UI 跨屏前端框架实现模板 <br> 支持多平台、终端<br>嗯嗯嗯，不知道说啥了。感谢这些开源的程序<br><br>
            Made with in Startblog v2.1 <a href="https://github.com/Cryin/Startblog"><span class="am-icon-github"></span> </a></p>
        </div>
        <div class="am-u-sm-12 am-u-md-4- am-u-lg-4">
            <h3>社交账号</h3>
            <p>
                <a href="tencent://message/?uin=416049355"><span class="am-icon-qq am-icon-fw am-primary blog-icon blog-icon"></span></a>
                <a href="https://github.com/Cryin/"><span class="am-icon-github am-icon-fw blog-icon blog-icon"></span></a>
                <a href="http://weibo.com/justear"><span class="am-icon-weibo am-icon-fw blog-icon blog-icon"></span></a>
                <a href=""><span class="am-icon-weixin am-icon-fw blog-icon blog-icon"></span></a>
                <a href="<?php echo base_url('/feed')?>"><span class="am-icon-rss am-icon-fw blog-icon blog-icon"></span></a>
            </p>
            <h3>贡献者</h3>
            <p>感谢辉哥设计的Logo，感谢贡献者LUHOO、Hardy、Ant、半城人...</p>          
        </div>
        <div class="am-u-sm-12 am-u-md-4- am-u-lg-4">
              <h1>站在巨人的肩膀上</h1>
             <h3>Heroes</h3>
            <p>
                <ul>
                    <li>Codeigniter</li>
                    <li>Amazeui</li>
                    <li>Simplemde</li>
                    <li>...</li>
                </ul>
            </p>
        </div>
    </div>    
    <div class="blog-text-center">©2014- 2016 Cryin' | Images: <a href="https://github.com/Cryin/Startblog">Startblog</a>
      <script language="javascript" type="text/javascript" src="http://js.users.51.la/19034341.js"></script>
<noscript><a href="http://www.51.la/?19034341" target="_blank"><img alt="&#x6211;&#x8981;&#x5566;&#x514D;&#x8D39;&#x7EDF;&#x8BA1;" src="http://img.users.51.la/19034341.asp" style="border:none" /></a></noscript>
    </div>    
  </footer>
