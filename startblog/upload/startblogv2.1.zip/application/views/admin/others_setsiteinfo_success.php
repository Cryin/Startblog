
<!-- 内容区域 -->
        <div class="tpl-content-wrapper">



            <div class="row-content am-cf">
                <div class="widget am-cf">
                    <div class="widget-body">
                        <div class="tpl-page-state">
                            <div class="tpl-error-title-info">操作提示</div>
                            <div class="tpl-page-state-content tpl-error-content">

                                <p>站点设置成功</p>
                                
                                <a class="am-btn am-btn-secondary am-radius" href="<?php echo site_url("admin/Others/show_siteinfo");?>">Back Home</a></div>

                        </div>
                    </div>
                </div>



            </div>
        </div>
        </div>
    </div>