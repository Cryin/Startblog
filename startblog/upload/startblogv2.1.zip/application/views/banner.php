<!-- banner start -->
<div class="am-g am-g-fixed blog-fixed am-u-sm-centered blog-article-margin">
    <div data-am-widget="slider" class="am-slider am-slider-b1" data-am-slider='{&quot;controlNav&quot;:false}' >
    <ul class="am-slides">
      <li>
            <a href="https://github.com/Cryin/Startblog"><img src="<?php echo base_url('/static/img/b1.jpg')?>"></a>
            
      </li>
      <li>
            <a href="https://github.com/Cryin/Startblog"><img src="<?php echo base_url('/static/img/b2.jpg')?>"></a>
            
      </li>
    </ul>
    </div>
</div>
<!-- banner end -->